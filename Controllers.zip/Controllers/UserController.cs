﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserRegistrationApp.Models;
using UserRegistrationApp.Services;

namespace UserRegistrationApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;

        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpPost]
        public async Task<IActionResult> CreateUser([FromBody] UserDto user)
        {
            if (user == null || !ModelState.IsValid)
            {
                return BadRequest("Invalid user data.");
            }

            await _userService.InsertUserAsync(user);
            return CreatedAtAction(nameof(GetUserById), new { id = user.Id }, user);
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<UserDto>>> GetAllUsers()
        {
            var users = await _userService.GetAllUsersAsync();
            return Ok(users);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<UserDto>> GetUserById(int id)
        {
            var user = await _userService.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }
            return Ok(user);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUser(int id, [FromBody] UserDto user)
        {
            if (id != user.Id || !ModelState.IsValid)
            {
                return BadRequest("Invalid user data.");
            }

            await _userService.UpdateUserAsync(user);
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUser(int id)
        {
            var user = await _userService.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }

            await _userService.DeleteUserAsync(id);
            return NoContent();
        }

        [HttpGet("states")]
        public IActionResult GetStates()
        {
            var states = new List<string> { "Gujarat", "Maharashtra" };
            return Ok(states);
        }

        [HttpGet("cities/{state}")]
        public IActionResult GetCities(string state)
        {
            var cities = state switch
            {
                "Gujarat" => new List<string> { "Surat", "Bardoli", "Baroda" },
                "Maharashtra" => new List<string> { "Mumbai", "Pune" },
                _ => new List<string>()
            };
            return Ok(cities);
        }
    }
}
