﻿using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UserRegistrationApp.Data;
using UserRegistrationApp.Models;

namespace UserRegistrationApp.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly RegistrationDbContext _context;

        public UserRepository(RegistrationDbContext context)
        {
            _context = context;
        }

        public async Task DeleteAsync(int id)
        {
            await _context.Database.ExecuteSqlRawAsync("EXEC sp_DeleteUser @Id", new SqlParameter("@Id", id));
        }

        public async Task<IEnumerable<UserDto>> GetAllAsync()
        {
            var users = await _context.UserDtos
        .FromSqlRaw("EXEC sp_GetAllUsers")
        .Select(user => new UserDto
        {
            Id = user.Id,
            Name = user.Name,
            Email = user.Email,
            Phone = user.Phone,
            Address = user.Address,
            State = user.State, // If applicable
            City = user.City    // If applicable
        })
        .ToListAsync();

            return users;
        }

        public async Task<UserDto> GetByIdAsync(int id)
        {
            return await _context.UserDtos.FromSqlRaw("EXEC sp_GetUserById @Id", new SqlParameter("@Id", id)).FirstOrDefaultAsync();
        }

        public async Task InsertAsync(UserDto user)
        {
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC sp_InsertUserRegistration @Name, @Email, @Phone, @Address, @StateId, @CityId",
                new SqlParameter("@Name", user.Name),
                new SqlParameter("@Email", user.Email),
                new SqlParameter("@Phone", user.Phone),
                new SqlParameter("@Address", user.Address ?? (object)DBNull.Value), // Handle null values
                new SqlParameter("@StateId", user.State),
                new SqlParameter("@CityId", user.City));
        }

        public async Task UpdateAsync(UserDto user)
        {
            await _context.Database.ExecuteSqlRawAsync(
                "EXEC sp_UpdateUserRegistration @Id, @Name, @Email, @Phone, @Address, @StateId, @CityId",
                new SqlParameter("@Id", user.Id),
                new SqlParameter("@Name", user.Name),
                new SqlParameter("@Email", user.Email),
                new SqlParameter("@Phone", user.Phone),
                new SqlParameter("@Address", user.Address ?? (object)DBNull.Value), // Handle null values
                new SqlParameter("@StateId", user.State),
                new SqlParameter("@CityId", user.City));
        }
    }
}
